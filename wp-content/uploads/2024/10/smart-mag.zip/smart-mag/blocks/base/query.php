<?php
namespace Bunyad\Blocks\Base;

use Bunyad;
use WP_Query;

/**
 * Dynamic Blocks Query Class
 */
class Query
{
	protected $block;
	protected $data = [];

	/**
	 * @param Bunyad_Blocks_Base $block
	 */
	public function __construct($block) 
	{
		$this->block = $block;
	}

	/**
	 * Process props and setup the query
	 * 
	 * @return WP_Query|null
	 */
	public function setup()
	{
		$props = $this->block->props;
		extract($props, EXTR_SKIP);

		// Have custom query args?
		$query_args = array('ignore_sticky_posts' => 1);

		if (isset($props['query_args']) && is_array($props['query_args'])) {
			$query_args = $props['query_args'];
		}
		
		$query_args = array_merge($query_args, array(
			'posts_per_page' => (!empty($posts) ? intval($posts) : 4), 
			'order'          => ($sort_order == 'asc' ? 'asc' : 'desc'),
			'post_status'    => 'publish',
			'offset'         =>  ($offset ? $offset : '')
		));
		
		// Add pagination if available
		$page = (get_query_var('paged') ? get_query_var('paged') : get_query_var('page'));
		if (!empty($page)) {
			$query_args['paged'] = $page;
		}
		
		/**
		 * Sortng criteria
		 */
		switch ($sort_by) {
			case 'modified':
				$query_args['orderby'] = 'modified';
				break;
				
			case 'random':
				$query_args['orderby'] = 'rand';
				break;
	
			case 'comments':
				$query_args['orderby'] = 'comment_count';
				break;
				
			case 'alphabetical':
				$query_args['orderby'] = 'title';
				break;
				
			case 'rating':
				$query_args = array_merge(
					$query_args, 
					array('meta_key' => '_bunyad_review_overall', 'orderby' => 'meta_value_num')
				);
				break; 	
		}
		
		/**
		 * Setup aliases for backward compatibility
		 */
		
		// if (!empty($cats)) {
		// 	$terms = $cats;
		// }
	
		// // Alias for heading
		// // Legacy: $title may be set by old block system 
		// if (empty($title)) {
		// 	$title = $heading;
		// }

		// // Legacy: $post_format
		// if (!empty($post_format)) {
		// 	$post_formats = $post_format;
		// }

		// // Legacy: $link
		// if (!empty($link)) {
		// 	$heading_link = $link;
		// }
		
		// Main category / taxonomy term object
		$term = '';
		
		// template helper variables
		$term_id   = '';
		$main_term = '';

		// Empty link by default.
		$link      = '';
		$title     = $heading;
			
		/**
		 * Limit by custom taxonomy?
		 */
		if (!empty($taxonomy)) {
	
			$_taxonomy = $taxonomy; // preserve
			
			// get the term
			$term = get_term_by('id', (!empty($cat) ? $cat : current($terms)), $_taxonomy);
			
			// add main cat to terms list
			if (!empty($cat)) {
				array_push($terms, $cat);
			}
			
			$query_args['tax_query'] = array(array(
				'taxonomy' => $_taxonomy,
				'field' => 'id',
				'terms' => (array) $terms
			));
			
			if (empty($title)) {
				$title = $term->slug; 
			}
			
			$link = get_term_link($term, $_taxonomy);
			
		}
		else {
			
			// terms / cats may have slugs instead of ids
			if (!empty($terms)) {
				
				if (count($terms) && !is_numeric($terms[0])) {
					$results = get_terms('category', array('slug' => $terms, 'hide_empty' => false, 'hierarchical' => false));
					$terms = wp_list_pluck($results, 'term_id');
				}
			}
			else {
				$terms = array();
			}
		
			/**
			 * Got main category/term? Use it for filter, link, and title
			 */
			if (!empty($cat)) {
				
				// Might be an id or a slug
				$term = $category = is_numeric($cat) ? get_category($cat) : get_category_by_slug($cat);
				
				// Category is always the priority main term
				$main_term = $term;
				
				if (!empty($category)) {
					array_push($terms, $category->term_id);
						
					if (empty($title)) {
						$title = $category->cat_name;
					}
				
					if (empty($link)) {
						$link = get_category_link($category);
					}
				}
			}
			
			/**
			 * Filtering by tag(s)?
			 */
			if (!empty($tags)) {
		
				// add query filter supporting multiple tags separated with comma
				$query_args['tag'] = $tags;
				
				// get the first tag
				$tax_tag = current($tags);
				$term = get_term_by('slug', $tax_tag, 'post_tag');

				// Use the first tag as main term if a category isn't already the main term
				if (!$main_term) {
					$main_term = $term;
				}
				
				if (empty($title)) {
					$title = $term->slug; 
				}
				
				if (empty($link)) {
					$link = get_term_link($term, 'post_tag');
				}
			}
			
			/**
			 * Multiple categories/terms filter
			 */
			if (count($terms)) {
				$query_args['cat'] = join(',', $terms);
				
				// No category as main and no tag either? Pick first category from multi filter
				if (!$main_term) {
					$main_term = current($terms);
				}
			}
		}

		/**
		 * By specific post IDs?
		 */
		if (!empty($post_ids)) {
			
			$ids = array_map('intval', $post_ids);
			$query_args['post__in'] = $ids;
		}
		
		/**
		 * Post Formats?
		 */
		if (!empty($post_formats)) {
			
			if (!isset($query_args['tax_query'])) {
				$query_args['tax_query'] = [];
			}

			// Add post format prefix
			$formats = array_map(function($val) {
				return 'post-format-' . trim($val);
			}, $post_formats);
			
			$query_args['tax_query'][] = [
				'taxonomy' => 'post_format',
				'field'    => 'slug',
				'terms'    => (array) $formats,
			];
		}
		
		/**
		 * Custom Post Types?
		 * 
		 * Legacy: Supports multiple post types
		 */
		if (!empty($post_type)) {
			$query_args['post_type'] = array_map('trim', explode(',', $post_type));
		}
		
		/**
		 * Execute the query
		 */

		// Add a filter
		$query_args  = apply_filters(
			'bunyad_block_query_args', 
			$query_args, 
			$this->block, 
			$this->block->props  // redundant but backward compatibility
		);

		$query = new WP_Query($query_args);
	
		// Disable title if empty
		if (empty($title)) {
			$this->block->props['heading_type'] = 'none';
		}
		
		// Setup accessible variables
		$this->data = array_merge($this->data, array(
			'heading_link'  => (!empty($heading_link) ? $heading_link : $link),
			'heading'       => $title,
			'query_args'    => $query_args,
			'query'         => $query,
			'term'    	    => $main_term, 
		));
		
		// Process filters
		$this->process_filters();

		return $this->data;
	}

	/**
	 * @uses Bunyad::registry()
	 */
	public function process_filters()
	{
		$props = $this->block->props;

		if (empty($props['filters'])) {
			return;
		}

		$display_filters = array();

		/**
		 * Process display filters - supports ids or slugs
		 */
		
		$filters_terms = $props['filters_terms'];
		
		// Which taxonomy? Default to category
		$tax = 'category';

		if ($props['filters'] == 'tag') {
			$tax = 'post_tag';	
		}
		else if ($props['filters'] == 'taxonomy' && !empty($props['filters_tax'])) {
			$tax = $props['filters_tax'];
		}
		
		// Auto-select 3 sub-cats for category if terms are missing
		if ($tax == 'category' && empty($filters_terms) && is_object($this->data['term'])) {

			$filters_terms = wp_list_pluck(
				get_categories(array(
					'child_of' => $this->data['term']->term_id, 
					'number'   => 3, 
					'hierarchical' => false
				)),
				'term_id'
			);
		}
		
		// Still no filter terms? 
		if (empty($filters_terms)) {
			return;
		}
		
		foreach ($filters_terms as $id) {
			
			// Supports slugs
			if (!is_numeric($id)) {
				$term = get_term_by('slug', $id, $tax);
			}
			else {
				$term = get_term($id);
			}
			
			if (!is_object($term)) {
				continue;
			}
			
			$link = get_term_link($term);
			$display_filters[] = '<li><a href="'. esc_url($link)  .'" data-id="' . esc_attr($term->term_id) . '">'. esc_html($term->name) .'</a></li>';
			
				
			/** 
			 * Add to the registry for preloading filter contents
			 */
			if (empty($filters_load) OR $filters_load == 'preload') {
				
				if (!Bunyad::registry()->block_filters_preload) {
					Bunyad::registry()->block_filters_preload = new \ArrayObject();
				}
				
				$atts = $props;
					
				// Don't need these attributes for filters
				unset(
					$atts['cat'], 
					$atts['cats'], 
					$atts['tags'], 
					$atts['filters'], 
					$atts['taxonomy'], 
					$atts['offset'],
					$atts['sub_cats'], // Legacy - prevent infinite loops
					$atts['sub_tags']  // Legacy
				);
				
				$atts = array_merge($atts, [
					'_is_filter'      => true,
					'use_query_props' => true,
					'terms'    => $term->term_id, 
					'filters'  => false,
					'taxonomy' => $tax
				]);
		
				// Add to global registry
				Bunyad::registry()->block_filters_preload[] = [
					'block_id'  => $this->block->id,
					'props'     => $atts,
					'unique_id' => $this->block->data['unique_id']
				];
			}

		} // foreach

		return ($this->data['display_filters'] = $display_filters);

	}

}