Documentation/User Manual available online at: http://theme-sphere.com/smart-mag/documentation/
