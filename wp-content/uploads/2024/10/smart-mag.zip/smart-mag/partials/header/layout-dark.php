<?php
/**
 * Partial: Dark Header
 */

$class = 'main-head dark';

include locate_template('partials/header/layout.php');