<?php
/**
 * Post Layout - Modern - B
 */

Bunyad::core()->partial('partials/single/layout-modern', array('is_dynamic' => false));