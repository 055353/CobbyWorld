<footer class="main-footer">
	<?php if (is_active_sidebar('lower-footer')): ?>
		<?php dynamic_sidebar('lower-footer'); ?>
	<?php endif; ?>
	
	<a href="#top" class="back-to-top"><?php esc_html_e('Back to top', 'bunyad'); ?></a>
</footer>