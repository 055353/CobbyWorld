<?php
/**
 * General Setup
 */
if ( ! function_exists( 'haste_general_setup' ) ) :
	function haste_general_setup() {

		/* Add RSS feed links to <head> for posts and comments */
		add_theme_support( 'automatic-feed-links' );

		/* Enable support for Post Thumbnails, and declare two sizes */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 660, 420, true );

		/* Other init */
		add_theme_support( 'title-tag' );
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption'
		) );

		/* Enable support for Post Formats */
		add_theme_support( 'post-formats', array(
			'gallery',
			'quote',
			'link',
			'video',
			'audio',
		) );

		/* Add theme support for custom header */
		add_theme_support( "custom-header" );
		add_theme_support( "custom-background" );

		/* Content Width */
		if ( !isset( $content_width ) ) :
			$content_width = 1200;
		endif;

	}
	add_action( 'init', 'haste_general_setup' );
endif;




/**
 * WooCommerce and Language Setup
 */
if ( ! function_exists( 'haste_woocommerce_language_setup' ) ) :
	add_action('after_setup_theme', 'haste_woocommerce_language_setup');
	function haste_woocommerce_language_setup(){

		/* Translations */
	    load_theme_textdomain( 'haste', get_template_directory() . '/languages' );

		if ( is_child_theme() ) {
			load_child_theme_textdomain( 'haste', get_stylesheet_directory() . '/languages' );
		}

	    /* Add WooCommerce support */
	    add_theme_support( 'woocommerce' );
	}
endif;




/**
 * Disable Elementor Font and Colors
 */
if ( ! function_exists( 'haste_disable_elementor_fonts' ) ) :
	add_action('after_switch_theme', 'haste_disable_elementor_fonts');
	function haste_disable_elementor_fonts () {
		/*
		** Add Portfolio Support for elementor
		*/
		$elementor_support = get_option( 'elementor_cpt_support' );
		// if DOESN'T exist
		if( !$elementor_support ) :
		    $elementor_support = [ 'page', 'post', 'haste-portfolio', 'haste-header', 'haste-footer' ]; //create array of our default supported post types
		    update_option( 'elementor_cpt_support', $elementor_support ); //write it to the database

		//if DOES exist
		elseif( is_array( $elementor_support ) ) :
			if( !in_array( 'haste-portfolio', $elementor_support ) ) :
				$elementor_support[] = 'haste-portfolio';
			endif;

			if( !in_array( 'haste-header', $elementor_support ) ) :
				$elementor_support[] = 'haste-header';
			endif;

			if( !in_array( 'haste-footer', $elementor_support ) ) :
				$elementor_support[] = 'haste-footer';
			endif;

		    update_option( 'elementor_cpt_support', $elementor_support ); //update database
		endif;


		// General settings
		update_option('elementor_container_width', '1170');
		update_option('elementor_global_image_lightbox', 'no');


		/*
		** Disable fonts from Elementor
		*/
		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );
	}
endif;



/**
 * Register Navigation
 */
register_nav_menus( array(
	'header'   => esc_html__( 'Header Navigation', 'haste' ),
	'topbar'   => esc_html__( 'Top Bar Navigation', 'haste' ),
	'footer'   => esc_html__( 'Footer Navigation', 'haste' ),
));




/**
 * Register Widget Areas
 */
if ( ! function_exists( 'haste_widgets' ) ) :
	function haste_widgets() {
		register_sidebar( array(
			'name'          => esc_html__( 'Page Widgets', 'haste' ),
			'id'            => 'page-widgets',
			'description'   => esc_html__( 'Appears in the page sidebar.', 'haste' ),
			'before_widget' => '<div id="%1$s" class="sh-widget-item %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="sh-sidebar-title"><h3 class="widget-title">',
			'after_title'   => '</h3></div>',
		));

		register_sidebar( array(
			'name'          => esc_html__( 'Blog Widgets', 'haste' ),
			'id'            => 'blog-widgets',
			'description'   => esc_html__( 'Appears in the blog page sidebar.', 'haste' ),
			'before_widget' => '<div id="%1$s" class="sh-widget-item %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="sh-sidebar-title"><h3 class="widget-title">',
			'after_title'   => '</h3></div>',
		));

		register_sidebar( array(
			'name'          => esc_html__( 'Footer Widgets', 'haste' ),
			'id'            => 'footer-widgets',
			'description'   => esc_html__( 'Appears when classic footer is being used', 'haste' ),
			'before_widget' => '<div id="%1$s" class="sh-widget-item %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="sh-sidebar-title"><h3 class="widget-title">',
			'after_title'   => '</h3></div>',
		));
	}

	add_action( 'widgets_init', 'haste_widgets' );
endif;




/**
 * Register Menus
 */
register_nav_menus( array(
	'header'   => esc_html__( 'Header Navigation', 'haste' ),
) );




/**
 * Register Header and Footer Posts
 */
if ( ! function_exists( 'haste_post_types' ) ) :
	function haste_post_types() {
		register_post_type( 'haste-portfolio',
	        array(
	            'labels' => array(
	                'name' => esc_attr__( 'Portfolio', 'haste' ),
	                'singular_name' => esc_attr__( 'Portfolio', 'haste' )
	            ),
	            'public' => true,
	            'has_archive' => true,
				'show_in_rest' => true,
				'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments', 'revisions', 'permalinks', 'featured_image' ),
				'rewrite' => array( 'slug' => 'haste-portfolio' ),
				'menu_icon' => 'dashicons-format-gallery',
				'taxonomies' => array( 'haste-portfolio-category' ),
				'capability_type' => 'page',
				'show_in_nav_menus' => true,
				'rewrite' => array(
					'slug' => 'portfolio'
				),
	        )
	    );
		register_taxonomy( 'haste-portfolio-category', array( 'haste-portfolio' ), array(
			'hierarchical' => true,
			'label' => 'Portfolio Categories',
			'singular_label' => 'Category',
			'rewrite' => array(
				'slug' => 'haste-portfolio-category',
				'with_front'=> false
			),
			'show_in_rest' => true,
		));
		register_taxonomy_for_object_type( 'haste-portfolio-category', 'haste-portfolio' );


	   /* register_post_type( 'haste-header',
	        array(
	            'labels' => array(
	                'name' => esc_attr__( 'Headers', 'haste' ),
	                'singular_name' => esc_attr__( 'Header', 'haste' )
	            ),
				'rewrite' => array( 'slug' => 'header' ),
	            'public' => true,
	            'has_archive' => true,
				'show_in_nav_menus' => true,
	        )
	    );


	    register_post_type( 'haste-footer',
	        array(
	            'labels' => array(
	                'name' => esc_attr__( 'Footers', 'haste' ),
	                'singular_name' => esc_attr__( 'Footer', 'haste' )
	            ),
				'rewrite' => array( 'slug' => 'footer' ),
	            'public' => true,
	            'has_archive' => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => true,
				'show_in_menu' => true,
				'show_ui' => true,
	        )
	    );*/
	}
	add_action( 'init', 'haste_post_types' );
endif;


/**
 * Add Theme Settings Link
 */
if ( is_user_logged_in() && !function_exists( 'haste_theme_settings_menu' ) ) :
	add_action( 'admin_bar_menu', 'haste_theme_settings_menu', 999 );
	function haste_theme_settings_menu( $wp_admin_bar ) {
	    $args = array(
	        'id'    => 'haste-theme-settings',
	        'title' => 'Haste Settings',
	        'href'  => get_admin_url().'admin.php?page=haste-theme-settings',
	    );
	    $wp_admin_bar->add_node( $args );
	}
endif;
