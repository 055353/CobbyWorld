<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }

$manifest = array();
$manifest['id'] = 'gillion';
$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['supported_extensions'] = array(
	'megamenu' => array(),
	'backups' => array()
);
