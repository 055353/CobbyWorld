<?php
	/* Header Right 1 */
?>

<?php /* Header */ ?>
<div class="sh-header-side">
	<?php if( is_active_sidebar( 'side-widgets' ) ) : ?>
		<?php
			ob_start();
			dynamic_sidebar( 'side-widgets' );
			wp_reset_postdata();
			$widgets = ob_get_clean();

			$widgets = preg_replace( '/<h3 class="widget-title">(.+)<\/h3>/', '<h5 class="widget-title">$1</h5>', $widgets );
			echo ( $widgets );
		?>
	<?php endif; ?>
</div>
<div class="sh-header-side-overlay"></div>
