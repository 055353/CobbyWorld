<div class="sh-footer-widgets">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <?php
        			ob_start();
        			dynamic_sidebar( 'footer-widgets1' );
        			wp_reset_postdata();
        			$widgets = ob_get_clean();

        			$widgets = preg_replace( '/<h3 class="widget-title">(.+)<\/h3>/', '<h4 class="widget-title">$1</h4>', $widgets );
        			echo ( $widgets );
        		?>
            </div>
            <div class="col-md-4 col-sm-6">
                <?php
        			ob_start();
        			dynamic_sidebar( 'footer-widgets2' );
        			wp_reset_postdata();
        			$widgets = ob_get_clean();

        			$widgets = preg_replace( '/<h3 class="widget-title">(.+)<\/h3>/', '<h4 class="widget-title">$1</h4>', $widgets );
        			echo ( $widgets );
        		?>
            </div>
            <div class="col-md-4 col-sm-6">
                <?php
        			ob_start();
        			dynamic_sidebar( 'footer-widgets3' );
        			wp_reset_postdata();
        			$widgets = ob_get_clean();

        			$widgets = preg_replace( '/<h3 class="widget-title">(.+)<\/h3>/', '<h4 class="widget-title">$1</h4>', $widgets );
        			echo ( $widgets );
        		?>
            </div>
        </div>
    </div>
</div>
