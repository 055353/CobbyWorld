<?php
/* Template Name: Footers */
get_header(); ?>

<div class="sh-footer-template">
    <div class="container">
        <?php the_content(); ?>
    </div>
</div>

<?php get_footer(); ?>
