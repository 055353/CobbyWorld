<?php

namespace Bunyad\Blocks\Base;

/**
 * Base Blocks Class.
 */
abstract class Block 
{
	/**
	 * @var array Properties/attributes for the block.
	 */
	public $props = [];

	/**
	 * @var string Identifier of the block - may also be used for block view.
	 */
	public $id  = '';

	/**
	 * @param array $props
	 */
	public function __construct($props = [])
	{
		if (is_array($props) && $props) {
			$props = $this->setup_props($props);

			// Override default props with processed props (by setup_props()).
			$this->props = array_replace(
				$this->get_default_props(),
				apply_filters('bunyad_blocks_setup_props', $props, $this->id)
			);
		}

		$this->init();
	}

	public function init() {}

	/**
	 * Get default props for this block.
	 *
	 * @return array
	 */
	abstract public static function get_default_props();

	/**
	 * Render and print the output, such as HTML.
	 */
	abstract public function render();

	/**
	 * Setup / process props before overriding the defaults with provided.
	 * 
	 * By default, removes:
	 * 
	 * 1. Unrecognized props (not in defaults array).
	 * 2. When the value is _default (forces to use default prop).
	 * 3. Props with same value as default.
	 * 
	 * To be used to extend properties for this block based on provided props, or when
	 * some computation is needed that's not available to the method get_default_props().
	 *
	 * @param array $props
	 * @return array
	 */
	public function setup_props($props) 
	{
		$defaults = $this->get_default_props();
		foreach ($props as $key => $value) {

			// Remove if unrecognized prop or has _default value.
            if (!array_key_exists($key, $defaults) || $value === '_default') {
				unset($props[$key]);
				continue;
			}

			/**
			 * If the default prop value is an array, the expected value is an array, so 
			 * strings should be split by comma separation.
			 */
			if (is_array($defaults[$key])) {
				
				$orig_is_array = true;

				// If it's an alias, check if the original is an array.
				if (array_key_exists('alias', $defaults[$key])) {
					$ref = $defaults[$key]['alias'];

					if (!is_array($defaults[$ref])) {
						$orig_is_array = false;
					}
				}

				if (is_string($value) && $orig_is_array) {
					$props[$key] = array_map(
						'trim', 
						explode(',', $value)
					);
				}

				// An array is expected for this key, cast it.
				if ($orig_is_array) {
					$props[$key] = (array) $value;
				}
			}
		}

		$props = $this->remove_defaults($props, $defaults);
		return $props;
	}

	/**
	 * Remove props with same value as default. 
	 * 
	 * Not too important, but can help if correct global/default value is not set.
	 *
	 * @param array $props
	 * @param array $defaults
	 * @return void
	 */
	protected function remove_defaults(array $props, $defaults = [])
	{
		foreach ($props as $key => $value) {
			
			/**
			 * We don't do strict matching in all cases for removal. Based on default prop type:
			 * 
			 * - Strict comparison for null type.
			 * - Following are considered equal:
			 * 
			 *  0     == ''
			 *  false == '0'
			 *  false == ''
			 *  true  == '1'
			 *  true  == 1
			 *  10    == '10'
			 *  []    == ''
			 * 
			 * - Loose comparison done for boolean, integer, float (double).
			 * - Strict comparison with cast for string type.
			 * - Arrays strict comparison to allow all order sort, with cast.
			 */
			$default = $defaults[$key];
			
			switch (gettype($default)) {

				case 'boolean':
				case 'integer':
				case 'double':
					$remove = $default == $value;
					break;

				case 'string':
					// Not entirely necessary, but good to cast to string first.
					$remove = (string) $default === (string) $value;
					break;

				case 'array':
					$remove = (array) $default === (array) $value;
					break;

				default:
					$remove = $default === $value;
					break;
			}

			if ($remove) {
				unset($props[$key]);
			}
		}

		return $props;
	}

	/**
	 * Magic method for print / echo.
	 */
	public function __toString() 
	{
		ob_start();
		$this->render();
		
		return ob_get_clean();
	}

}