<?php

/**
 * Fields to show for page meta box
 */

$options = array(
	array(
		'label' => __('Enable Review?', 'bunyad-admin'),
		'name'  => 'reviews', 
		'type'  => 'checkbox',
		'value' => 0,
	),

	array(
		'label' => __('Display Position', 'bunyad-admin'),
		'name'  => 'review_pos',
		'type'  => 'select',
		'options' => array(
			'none' => __('Do not display - Disabled', 'bunyad-admin'), 
			'top'  => __('Top', 'bunyad-admin'),
			'bottom' => __('Bottom', 'bunyad-admin')
		)
	),
	
	array(
		'label' => __('Show Rating As', 'bunyad-admin'),
		'name'  => 'review_type',
		'type'  => 'radio',
		'options' => array(
			'percent' => __('Percentage', 'bunyad-admin'),
			'points'  => __('Points', 'bunyad-admin'),
			'stars'   => __('Stars', 'bunyad-admin'),
		), 
		'value' => 'points',
	),


	array(
		'label'  => __('Review Type/Schema', 'bunyad-admin'),
		'name'   => 'review_schema',
		'type'   => 'select',
		'options' => array(
			''                   => 'Default (Product)',
			'none'               => 'Disabled',
			// 'Book'               => 'Book',
			'Course'             => 'Course',
			'CreativeWorkSeason' => 'CreativeWorkSeason',
			'CreativeWorkSeries' => 'CreativeWorkSeries',
			'Episode'            => 'Episode',
			// 'Event'              => 'Event',
			'Game'               => 'Game',
			// 'HowTo'              => 'HowTo',
			'LocalBusiness'      => 'LocalBusiness',
			'MediaObject'        => 'MediaObject',
			'Movie'              => 'Movie',
			'MusicPlaylist'      => 'MusicPlaylist',
			'MusicRecording'     => 'MusicRecording',
			'Organization'       => 'Organization',
			'Product'            => 'Product',
			'Recipe'             => 'Recipe',
			// 'SoftwareApplication' => 'SoftwareApplication',
		)
	),

	array(
		'label' => __('Schema: Author / Brand / Org', 'bunyad-admin'),
		'desc'  => 'Note: For schema "Product", this field should have brand/company of product. For CreativeWorks and Books it can be Author/Publisher.',
		'name'  => 'review_item_author',
		'type'  => 'text',
	),

	array(
		'label' => __('Schema: Author Type', 'bunyad-admin'),
		'name'  => 'review_item_author_type',
		'type'  => 'select',
		'options' => [
			'organization' => 'Organization',
			'person'       => 'Person',
		]
	),
	
	array(
		'label' => __('Schema: Official Link', 'bunyad-admin'),
		'name'  => 'review_item_link',
		'desc'  => 'Required for: Movie - Optional for other types. Link to the Wikipedia/offical website/item site.',
		'type'  => 'text',
	),

	array(
		'label' => __('Schema: Item Name (Optional)', 'bunyad-admin'),
		'name'  => 'review_item_name',
		'type'  => 'text',
	),


	
	array(
		'label' => __('Heading (Optional)', 'bunyad-admin'),
		'name'  => 'review_heading',
		'type'  => 'text',
	),
	
	array(
		'label' => __('Verdict', 'bunyad-admin'),
		'name'  => 'review_verdict',
		'type'  => 'text',
		'value' => __('Awesome', 'bunyad-admin'),
	),
	
	array(
		'label' => __('Verdict Summary', 'bunyad-admin'),
		'name'  => 'review_verdict_text',
		'type'  => 'textarea',
		'options' => array('rows' => 5, 'cols' => 90),
		'value' => '',
	),
	
);