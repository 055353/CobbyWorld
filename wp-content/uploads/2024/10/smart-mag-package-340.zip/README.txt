Documentation/User Manual available online at: https://theme-sphere.com/smart-mag/documentation/
