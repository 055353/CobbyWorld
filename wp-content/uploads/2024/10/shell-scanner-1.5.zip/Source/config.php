<?php return array (
  'username' => '',
  'password' => '',
  'file-extensions' => 'php|phtml|php3|php4|php5|phps|htaccess|txt|gif',
  'ignored-dirs' => '.|..|.DS_Store|.svn|.git',
  'scan-dir' => '../',
  'additional-strings' => '',
); ?>